/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import abc.emi;
import java.io.IOException;
import java.io.PrintWriter;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author LENOVO
 */
public class calc_emi extends HttpServlet {
    @EJB
    private emi emi;
     
       protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
           double p = Double.parseDouble(request.getParameter("p"));
           double r = Double.parseDouble(request.getParameter("r"));

           int m = 60; // Loan tenure is fixed at 60 months

        
        double res = emi.find_emi(p, r, m);

        PrintWriter out = response.getWriter();
        out.println("<p>Your monthly EMI is: <strong>"+res+"</strong></p>");        

       }
}