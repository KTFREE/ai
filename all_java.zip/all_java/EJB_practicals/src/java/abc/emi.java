/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package abc;

import javax.ejb.Stateless;

/**
 *
 * @author LENOVO
 */
@Stateless
public class emi {

    public Double find_emi(double p, double r, int m) {
        double mir = (r / 100) / 12;
       
        double f_emi = (p * mir * Math.pow(1 + mir, m)) /
                (Math.pow(1 + mir, m) - 1);

        return f_emi;
       
    }
    
    

    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")
}
