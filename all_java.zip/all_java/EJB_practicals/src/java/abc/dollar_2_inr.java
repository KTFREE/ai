/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package abc;

import javax.ejb.Stateless;

/**
 *
 * 
 */
@Stateless
public class dollar_2_inr {

    public Double convert_inr(double d) {
        return d * 83.0;
    }
    
    public Double convert_euro(double d) {
        return d * 0.91;
    }
    
    
}
