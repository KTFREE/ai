/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.example;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;


/**
 * student db->>
 * create table practice (name VARCHAR(12));
 */
@ManagedBean(name = "iuds")
@RequestScoped
public class IUDSBean {

    private List<String> list= new ArrayList<String>();
           
    private String n;

    public String getN() {
        return n;
    }

    public void setN(String n) {
        this.n = n;
    }
    private String message;

    public String getMessage() {
        return message;
    }
    private String noname;

    public String getNoname() {
        return noname;
    }

    public void setNoname(String noname) {
        this.noname = noname;
    }

    public List<String> getList() {
        return list;
    }

    public void setList(List<String> list) {
        this.list = list;
    }
    
    private String fname;

    public String getFname() {
        return fname;
    }

    public String getTname() {
        return tname;
    }
    private String tname;

    public void setFname(String fname) {
        this.fname = fname;
    }

    public void setTname(String tname) {
        this.tname = tname;
    }
    
    
    public void insert() {
        String no = n;
        try{
            Connection conn = connection.getConnection();        
            PreparedStatement stmt = conn.prepareStatement("INSERT INTO practice VALUES ('"+no+"')");                       
            stmt.executeUpdate();
            message = "data inserted";
            }
        catch (Exception e) {
            message = e.getMessage();
        }
    }
    
    public void update() {
           try{
            Connection conn = connection.getConnection();        
            PreparedStatement stmt = conn.prepareStatement("update practice set name = '"+tname+"'where name = '"+fname+"'");             
            stmt.executeUpdate();
            message = "data updated";
            } 
        catch (SQLException e) {
            message = e.getMessage();
        } 
    }
    
    public void delete() {
        try{
            Connection conn = connection.getConnection();        
            PreparedStatement stmt = conn.prepareStatement("delete from practice where name = '"+noname+"'");             
            stmt.executeUpdate();
            message = "data deleted";
            } 
        catch (SQLException e) {
            message = e.getMessage();
        }
    }
        public void select() {
        list.clear(); 

        try {
            Connection conn = connection.getConnection(); 
            PreparedStatement stmt = conn.prepareStatement("select name from practice"); 
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) { 
                list.add(rs.getString("name"));
            }

        } catch (SQLException e) {
            message = e.getMessage();
        }
    }

     
    public IUDSBean() {
        
    }
    
}
