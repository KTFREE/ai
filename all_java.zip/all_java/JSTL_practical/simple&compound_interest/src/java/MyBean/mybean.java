/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB40/StatelessEjbClass.java to edit this template
 */
package MyBean;

import jakarta.ejb.Local;
import jakarta.ejb.Stateless;

@Stateless
@Local
public class mybean {

    
    public double calculateSimpleInterest(double principal, double rate, int time) {
        return (principal * rate * time) / 100;
    }

    
    public double calculateCompoundInterest(double principal, double rate, int time, int n) {
        return principal * Math.pow(1 + (rate / (n * 100)), n * time) - principal;
    }
}
